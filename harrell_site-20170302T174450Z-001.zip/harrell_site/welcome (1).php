<?php session_start();  
include 'include/session.php';
 ?>

 
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Clothing App - Welcome Page - Marshall</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="welcome.php">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li id="home"><a href="welcome.php">Home</a></li>
        <li id="size"><a href="size_view.php">Sizes</a></li>
        <li id="fabric"><a href="fabrics_view.php">Fabric Color</a></li>
		<li id="pattern"><a href="style_view.php">Pattern Style</a></li>
        
      </ul>
      <ul class="nav navbar-nav navbar-right">
       	<li id="machine"><a href="machineconfig_view.php">Machine Config</a></li>
       	
      </ul>
    </div>
  </div>
</nav> 
<script>
	$(document).ready(function(){
		$('#home').addClass('active');
	});
</script>
  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-8 text-center col-lg-12"> 
      <h1>Welcome, Lynzee!</h1>    </div>
  </div>
</div>

<footer class="container-fluid text-center">
  <p>A Website by Harrell Designs<br>
  <a href="include/logout.php">Logout</a></p>
</footer>
</body>
</html>