<?php
$host = 'localhost';
$username = 'harrell';
$password = 'kayden09';
$database = 'harrell';
$link = mysqli_connect($host,$username,$password,$database);

?>
