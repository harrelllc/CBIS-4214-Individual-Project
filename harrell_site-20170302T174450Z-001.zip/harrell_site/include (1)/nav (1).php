<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="welcome.php">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li id="home"><a href="welcome.php">Home</a></li>
        <li id="size"><a href="size_view.php">Sizes</a></li>
        <li id="fabric"><a href="fabric_view.php">Fabric Color</a></li>
		<li id="pattern"><a href="style_view.php">Pattern Style</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
       	<li id="machine"><a href="machine_config_view.php">Machine Config</a></li>
      </ul>
    </div>
  </div>
</nav> 




