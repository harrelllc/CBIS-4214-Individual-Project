<?php session_start();  
include 'include/session.php';
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Clothing App - Welcome Page - Marshall</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'include/nav.php';?>
	
	<!-- CONTENT AREA -->
	<div id="content_area">
<div id="main_content">

<p style="font-weight: bold; font-size: 23px;" class="text-center text-capitalize">
  Add Sizes</p>
    <select name="size_id" class="size_id">
        <option value="">Select Size ID</option>
        <option value="sm">SM</option>
        <option value="md">MD</option>
        <option value="lg">LG</option>
      </select>
    <select name="size_name" class="size_name">
        <option value="">Select Size Name</option>
        <option value="Small">Small</option>
        <option value="Medium">Medium</option>
        <option value="Large">Large</option>
      </select>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp; </p>
      <p>
  <label>Bust Size:</label>
  <input name="bust_size" type="text" id="bust_size" size="15">
        <label>Hip Size:</label>
        <input name="hip_size" type="text" id="hip_size" size="15">
        <label>Waist Size:</label>
        <input name="waist_size" type="text" id="waist_size" size="15">
      </p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p><a href="size_view.php" class="submit_button">Submit</a></p>
      <p>
        <a href="size_add.php" class="reset_button">Reset</a></p>
  </div>
	<!-- FOOTER -->
	<div id="footer">Footer</div>
</div><!-- END CONTAINER -->
<script src="../js/jquery-1.11.3.min.js"></script>
<script src="../js/bootstrap.js"></script>
</body>
</html>