<?php session_start();

$size_id = $SESSION['size_id'];
$size_name = $_POST['size_name'];
$bust_size = $_POST['bust_size'];
$hip_size = $_POST['hip_size'];
$waist_size = $_POST['waist_size'];

include '../include/connect.php';

$query = "UPDATE sizes SET size_name='$size_name', bust_size='$bust_size', hip_size='$hip_size', waist_size='$waist_size' WHERE size_id='$size_id';";

if (mysqli_query($link, $query)) {
	header("Location:../size_view.php");;
	
}else {
	echo "Error updating record: " . mysqli_error($link);
	
}

mysqli_close($conn);
?>