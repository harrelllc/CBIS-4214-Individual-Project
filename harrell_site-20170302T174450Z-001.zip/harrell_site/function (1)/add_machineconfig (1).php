<?php session_start ();

$config_description = $_POST['config_description'];

include '../include/connect.php';

$query = "INSERT INTO machine_config (config_description) VALUES ('$config_description');";

if (mysqli_query($link, $query)){
	header("Location:../machine_config_view.php");;
	
} else {
	echo "Error updating record: " . mysqli_error($link);
}

mysqli_close($conn);
?>