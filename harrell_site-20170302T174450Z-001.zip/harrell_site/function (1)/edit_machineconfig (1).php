<?php session_start();

$config_id = $SESSION['config_id'];
$config_description = $_POST['config_description'];

include '../include/connect.php';

$query = "UPDATE machine_config SET config_description='$config_description' WHERE config_id='$config_id';";

if (mysqli_query($link, $query)) {
	header("Location:../machine_config_view.php");;
	
}else {
	echo "Error updating record: " . mysqli_error($link);
	
}

mysqli_close($conn);
?>