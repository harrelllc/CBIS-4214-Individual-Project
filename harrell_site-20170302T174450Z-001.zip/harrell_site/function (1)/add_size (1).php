<?php session_start ();

$size_name = $_POST['size_name'];
$bust_size = $_POST['bust_size'];
$hip_size = $_POST['hip_size'];
$waist_size = $_POST['waist_size'];

include '../include/connect.php';

$query = "INSERT INTO sizes (size_name, bust_size, hip_size, waist_size) VALUES ('$size_name', '$bust_size', '$hip_size', '$waist_size');";

if (mysqli_query($link, $query)){
	header("Location:../size_view.php");;
	
} else {
	echo "Error updating record: " . mysqli_error($link);
}

mysqli_close($conn);
?>