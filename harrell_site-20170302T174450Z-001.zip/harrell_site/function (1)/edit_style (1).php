<?php session_start ();

$fabric_color_description = $_POST['fabric_color_description'];
$config_id = $_POST['config_id'];
$yarn_id = $_POST['yarn_id'];

include '../include/connect.php';

$query = "INSERT INTO fabric_colors (fabric_color_description, config_id, yarn_id) VALUES ('$fabric_color_description', '$config_id', '$yarn_id');";

if (mysqli_query($link, $query)){
	header("Location:../fabric_view.php");;
	
} else {
	echo "Error updating record: " . mysqli_error($link);
}

mysqli_close($conn);
?>