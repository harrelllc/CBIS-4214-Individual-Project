<?php session_start();  
include 'include/session.php';
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Clothing App - Welcome Page - Harrell</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'include/nav.php';?>
	
	<!-- CONTENT AREA -->
	<h1>Edit Fabric Color <?php echo "$fabric_colo_description"; ?></h1>
	<form action="function/edit_fabric.php" method="post">
		<table width="100%">
			<tbody>
				<tr>
					<th scope="col"> Fabric Color Description</th>
					<th scope="col"> Config ID</th>
					<th scope="col"> Yarn ID</th>
					
				</tr>
				<tr>
					
<?php
					
	//include the connection
	include 'include/connect.php';
					
	//select query to get database info
	$query = "select * from fabric_colors where colo_id = '$color_id'";
					
	$result = mysqli_query($link,$query);
					
	//load the info into the row
	$row = mysqli_fetch_assoc($result);
					echo "<td><input type='text' name='fabric_color_description' value='$fabric_color_description'></td>";
					echo "<td><input type='text' name='config_id' value='" . $row["config_id"]. "'></td>";
					echo "<td><input type='text' name='yarn_id' value='" . $row["yarn_id"]. "'></td>";
					
					
   ?>
   </tr>
   <tr>
   <td>&nbsp;</td>	
   </tr>	
  </tbody>
 </table>
 
 <input class="btn btn-success" type="submit">
 <input class="btn btn-danger" type="button" onclick="window.location.replace('fabric_view.php')" value="Cancel" />
	</form>
	<!-- FOOTER -->
	<?php include 'include/footer.php';?>
	<!-- END CONTAINER -->
</body>
</html>