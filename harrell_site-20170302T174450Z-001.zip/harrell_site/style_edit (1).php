<?php session_start();  
include 'include/session.php';
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Clothing App - Welcome Page - Harrell</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'include/nav.php';?>
	
	<!-- CONTENT AREA -->
	<h1>Edit Pattern Style <?php echo "$style_name"; ?></h1>
	<form action="function/edit_style.php" method="post">
		<table width="100%">
			<tbody>
				<tr>
					<th scope="col"> Style Name</th>
				</tr>
				<tr>
					
<?php
					
	//include the connection
	include 'include/connect.php';
					
	//select query to get database info
	$query = "select * from pattern_style where style_id = '$style_id'";
					
	$result = mysqli_query($link,$query);
					
	//load the info into the row
	$row = mysqli_fetch_assoc($result);
					echo "<td><input type='text' name='style_name' value='$style_name'></td>";
					
   ?>
   </tr>
   <tr>
   <td>&nbsp;</td>	
   </tr>	
  </tbody>
 </table>
 
 <input class="btn btn-success" type="submit">
 <input class="btn btn-danger" type="button" onclick="window.location.replace('style_view.php')" value="Cancel" />
	</form>
	<!-- FOOTER -->
	<?php include 'include/footer.php';?>
	<!-- END CONTAINER -->
</body>
</html>