<?php session_start();  
include 'include/session.php';
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Clothing App - Welcome Page - Marshall</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'include/nav.php';?>
	
	<!-- CONTENT AREA -->
	<div id="content_area">
<div id="main_content">

<p style="font-weight: bold; font-size: 23px;" class="text-center text-capitalize">
  Add Fabric Colors</p>
    <select name="color_id" class="color_id">
        <option value="">Select Color ID</option>
        <option value="1801-001">1801-001</option>
        <option value="1801-002">1801-002</option>
        <option value="1802-001">1802-001</option>
      </select>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>
        <label for="textarea">Fabric Color Description:</label>
        <input name="textfield" type="text" id="textfield" size="40">
      </p>
      <p>&nbsp;</p>
      <p><a href="fabric_view.php" class="submit_button">Submit </a></p>
      <p><a href="fabric_add.php" class="reset_button">Reset</a></p>
  </div>
	<!-- FOOTER -->
	<div id="footer">Footer</div>
</div><!-- END CONTAINER -->
<script src="../js/jquery-1.11.3.min.js"></script>
<script src="../js/bootstrap.js"></script>
</body>
</html>