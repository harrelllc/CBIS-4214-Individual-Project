<?php session_start();  
include 'include/session.php';
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Clothing App - Welcome Page - Harrell</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'include/nav.php';?>
	
	
	<!-- CONTENT AREA -->
		<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-6 text-left col-lg-6"> 
     <h1 align="center">Pattern Style</h1>

<table align="center" cellpadding="25" cellspacing="25" border="1" id="user_table" width="75%">
        <tr>
            <th>Style ID</th>
            <th>Style Name</th>
          
        </tr>

		     	  
<?php
include 'include/connect.php';
				$query = "select * from pattern_style";
				
				$result = mysqli_query($link,$query);
				
				if (mysqli_num_rows($result) > 0 ) {
					//output each row
					while ($row = mysqli_fetch_assoc($result)){
						echo "<tr id ='" . $row["style_id"]. "';>";
						echo "<td id ='style_id'><a href='style_edit.php?style_id=". $row["style_id"] . "'>". $row["style_id"] . "</a></td>";
						echo "<td id='style_name'>" . $row["style_name"]. "</td>";
						
						
					} 
				}
?>		
</tr>

</table>
</form> 
<div class="container-fluid" align="center">
			<a href="style_add.php"><button type="button" class="btn btn-primary">Add a Style</button></a>
</div>
			  
<br>
			  
	<!-- FOOTER -->
	<?php include 'include/footer.php';?>
</div><!-- END CONTAINER -->
</body>
</html>